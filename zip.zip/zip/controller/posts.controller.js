const postsController = {
    getAll : (req,res) =>{

        try{
            res.json({ message: "Get all posts" });
        }catch(error){
            console.log(error);
        }

    }
}